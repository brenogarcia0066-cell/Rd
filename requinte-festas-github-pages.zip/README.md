# Requinte Festas

Site estático pronto para publicação no **GitHub Pages**.

## Como publicar

1. Crie um repositório no GitHub.
2. Envie o arquivo `index.html` para a raiz do repositório.
3. Vá em **Settings → Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**.
5. Escolha a branch `main` e a pasta `/ (root)`.
6. Salve e aguarde a publicação.

## Importante sobre os dados

O sistema usa `localStorage` e `IndexedDB` do navegador. Portanto, os cadastros e fotos ficam salvos **no navegador/dispositivo em que foram cadastrados**. O GitHub Pages hospeda a interface, mas não fornece um banco de dados compartilhado para este arquivo.

O botão **Exportar backup** permite salvar os dados dos cadastros em JSON.
